import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import main  # noqa: E402
from evaluation import main as evaluation  # noqa: E402


class DeletionIntentTests(unittest.TestCase):
    def test_explicit_erasure_request_is_authorized(self) -> None:
        self.assertTrue(main.request_authorizes_deletion("Please erase my account."))

    def test_export_request_is_not_deletion(self) -> None:
        self.assertFalse(main.request_authorizes_deletion("Please export my account data."))

    def test_explicit_do_not_delete_is_not_authorized(self) -> None:
        self.assertFalse(main.request_authorizes_deletion("Do not delete my account."))

    def test_nonstandard_timestamp_is_parsed_for_historical_identity(self) -> None:
        event_time = main.parse_time("2026:08- 27T10:00:00Z")
        cutoff = main.parse_time("2026-08-28T00:00:00Z")
        self.assertIsNotNone(event_time)
        self.assertIsNotNone(cutoff)
        identifiers = main.subject_identifiers(
            "user_7",
            "new@example.test",
            cutoff,
            {"updated_at": "2026-08-27T12:00:00Z"},
            [
                {
                    "user_id": "user_7",
                    "event_time": "2026:08- 27T10:00:00Z",
                    "field_name": "email",
                    "old_value": "old@example.test",
                    "new_value": "new@example.test",
                }
            ],
        )
        self.assertIn("old@example.test", identifiers)

    def test_historical_identity_after_cutoff_is_excluded(self) -> None:
        cutoff = main.parse_time("2026-08-27T09:00:00Z")
        self.assertIsNotNone(cutoff)
        identifiers = main.subject_identifiers(
            "user_7",
            "new@example.test",
            cutoff,
            {"updated_at": "2026-08-28T12:00:00Z"},
            [
                {
                    "user_id": "user_7",
                    "event_time": "2026:08- 27T10:00:00Z",
                    "field_name": "email",
                    "old_value": "old@example.test",
                    "new_value": "new@example.test",
                }
            ],
        )
        self.assertNotIn("old@example.test", identifiers)

    def test_email_first_associated_after_cutoff_does_not_resolve_user(self) -> None:
        observed_at = "2026-01-01T12:00:00Z"
        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "old@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "new@example.test", "updated_at": "2026-01-03T00:00:00Z"}},
            {"old@example.test": {"user_1"}},
            [
                {
                    "user_id": "user_1",
                    "event_time": "2026-01-03T00:00:00Z",
                    "field_name": "email",
                    "old_value": "old@example.test",
                    "new_value": "new@example.test",
                }
            ],
            [
                main.Evidence(
                    "account_service",
                    "account_1",
                    "USER_PROFILE",
                    "ABSENT",
                    "evidence_1",
                    observed_at,
                    {"user_id": "user_1"},
                    "",
                )
            ],
            {"evidence_1": observed_at},
            [],
            {},
        )

        self.assertEqual((status, steps), ("INCOMPLETE", []))

    def test_email_in_pre_cutoff_identity_history_resolves_user(self) -> None:
        observed_at = "2026-01-01T12:00:00Z"
        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "old@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "new@example.test", "updated_at": observed_at}},
            {"old@example.test": {"user_1"}},
            [
                {
                    "user_id": "user_1",
                    "event_time": "2026-01-01T00:00:00Z",
                    "field_name": "email",
                    "old_value": "old@example.test",
                    "new_value": "new@example.test",
                }
            ],
            [
                main.Evidence(
                    "account_service",
                    "account_1",
                    "USER_PROFILE",
                    "ABSENT",
                    "evidence_1",
                    observed_at,
                    {"user_id": "user_1"},
                    "",
                )
            ],
            {"evidence_1": observed_at},
            [],
            {},
        )

        self.assertEqual(status, "COMPLETE")
        self.assertEqual(
            [(item["resource_id"], item["operation"]) for item in steps],
            [("account_1", "VERIFY_RECORD_ABSENT")],
        )


class EvidenceAndOrderingTests(unittest.TestCase):
    def test_unlinked_anonymized_analytics_record_is_not_attributed(self) -> None:
        record = main.Evidence(
            "analytics_platform",
            "analytics_1",
            "ANALYTICS_PROFILE",
            "ANONYMIZED",
            "analytics_evidence",
            "2026-01-01T12:00:00Z",
            {
                "user_id": None,
                "customer_reference": None,
                "email": None,
                "email_hash": None,
                "phone": None,
            },
            "",
        )

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [record],
            {"analytics_evidence": "2026-01-01T12:00:00Z"},
            [],
            {"ANALYTICS_PROFILE": "ANONYMIZE"},
        )

        self.assertEqual((status, steps), ("INCOMPLETE", []))

    def test_post_cutoff_security_record_does_not_enter_audit(self) -> None:
        observed_at = "2026-01-01T12:00:00Z"
        account = main.Evidence(
            "account_service", "account_1", "USER_PROFILE", "ABSENT",
            "account_evidence", observed_at, {"user_id": "user_1"}, "",
        )
        security = main.Evidence(
            "security_service", "audit_record_1", "SECURITY_AUDIT_LOG", "PRESENT",
            "late_security_evidence", observed_at, {"subject_reference": "user_1"}, "",
        )

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [account, security],
            {
                "account_evidence": observed_at,
                "late_security_evidence": "2026-01-03T00:00:00Z",
            },
            [],
            {"USER_PROFILE": "DELETE", "SECURITY_AUDIT_LOG": "RETAIN"},
        )

        self.assertEqual(status, "COMPLETE")
        self.assertEqual(
            [(item["resource_id"], item["operation"]) for item in steps],
            [("account_1", "VERIFY_RECORD_ABSENT")],
        )

    def test_linked_retained_security_record_gets_present_verification(self) -> None:
        observed_at = "2026-01-01T12:00:00Z"
        record = main.Evidence(
            "security_service",
            "audit_record_1",
            "SECURITY_AUDIT_LOG",
            "PRESENT",
            "security_evidence",
            observed_at,
            {"subject_reference": "user_1", "event_name": "account_deletion_reviewed"},
            "",
        )

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [record],
            {"security_evidence": observed_at},
            [],
            {"SECURITY_AUDIT_LOG": "RETAIN"},
        )

        self.assertEqual(status, "COMPLETE")
        self.assertEqual(
            [(item["resource_id"], item["operation"], item["evidence_id"]) for item in steps],
            [("audit_record_1", "VERIFY_RECORD_PRESENT", "security_evidence")],
        )

    def test_document_ocr_normalizes_spaced_resource_ids_and_subjects(self) -> None:
        records = main.document_evidence(
            "Subject filter: user 03; audit record 003, Account closure recorded.",
            Path("security_audit_explorer.png"),
            "evidence_ocr",
            "2026-09-05T07:00:00Z",
        )

        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].resource_id, "audit_record_003")
        self.assertEqual(records[0].category, "SECURITY_AUDIT_LOG")
        self.assertEqual(records[0].fields["subject_reference"], "user_03")

    def test_document_ocr_recognizes_marketing_profile_resources(self) -> None:
        records = main.document_evidence(
            "marketing_001 sj.park@naver.com Live",
            Path("marketing_profile_console.png"),
            "evidence_marketing",
            "2026-09-16T07:20:00Z",
        )

        self.assertEqual(len(records), 1)
        self.assertEqual(records[0].resource_id, "marketing_001")
        self.assertEqual(records[0].system_id, "marketing_platform")
        self.assertEqual(records[0].category, "MARKETING_PROFILE")

    def test_remediation_uses_the_loaded_policy_action(self) -> None:
        rules = main.load_policy(Path(__file__).resolve().parents[2] / "dataset")
        analytics = main.Evidence(
            "analytics_platform",
            "analytics_1",
            "ANALYTICS_PROFILE",
            "PRESENT",
            "evidence_1",
            "2026-01-01T00:00:00Z",
            {},
            "",
        )
        self.assertEqual(
            main.remediation_for(analytics, "REPORT_EXPOSED_PII", rules),
            ("ANONYMIZE_RECORD", "ANONYMIZED"),
        )

    def test_subject_reference_matches_stable_user_id(self) -> None:
        record = main.Evidence(
            "security_service",
            "audit_record_9",
            "SECURITY_AUDIT_LOG",
            "PRESENT",
            "evidence_1",
            "2026-01-01T00:00:00Z",
            {"subject_reference": "user_9"},
            "",
        )
        self.assertTrue(main.evidence_matches(record, "user_9", set()))

    def test_correlation_key_matches_stable_user_id(self) -> None:
        record = main.Evidence(
            "security_service",
            "audit_record_10",
            "SECURITY_AUDIT_LOG",
            "PRESENT",
            "evidence_2",
            "2026-01-01T00:00:00Z",
            {"correlation_key": "user_10"},
            "",
        )
        self.assertTrue(main.evidence_matches(record, "user_10", set()))

    def test_stale_contact_lookup_requires_delete_not_redaction(self) -> None:
        record = main.Evidence(
            "support_platform",
            "support_2",
            "SUPPORT_MESSAGE",
            "PRESENT",
            "evidence_3",
            "2026-01-01T00:00:00Z",
            {"event": "deletion_marker_check", "marker_found": "false"},
            "",
        )
        self.assertEqual(
            main.finding_for(record, main.evidence_state(record)),
            ("REPORT_REMAINING_RECORD", "PRESENT"),
        )
        self.assertEqual(
            main.remediation_for(record, "REPORT_REMAINING_RECORD", {"SUPPORT_MESSAGE": "REDACT"}),
            ("DELETE_RECORD", "ABSENT"),
        )

    def test_contact_query_row_is_reported_and_deleted(self) -> None:
        record = main.Evidence(
            "analytics_platform",
            "analytics_11",
            "ANALYTICS_PROFILE",
            "PRESENT",
            "evidence_4",
            "2026-01-01T00:00:00Z",
            {"event": "contact_lookup_completed", "rows": "1"},
            "",
        )
        self.assertEqual(
            main.finding_for(record, main.evidence_state(record)),
            ("REPORT_REMAINING_RECORD", "PRESENT"),
        )
        self.assertEqual(
            main.remediation_for(record, "REPORT_REMAINING_RECORD", {"ANALYTICS_PROFILE": "ANONYMIZE"}),
            ("DELETE_RECORD", "ABSENT"),
        )

    def test_order_matches_all_operation_priorities(self) -> None:
        operation_phases = {
            "REPORT_REMAINING_RECORD": "FINDING",
            "REPORT_EXPOSED_PII": "FINDING",
            "REPORT_ACTIVE_DATA_FLOW": "FINDING",
            "REPORT_RESTORE_RISK": "FINDING",
            "DISABLE_DATA_FLOW": "REMEDIATION",
            "BLOCK_RESTORE": "REMEDIATION",
            "DELETE_RECORD": "REMEDIATION",
            "REDACT_RECORD": "REMEDIATION",
            "ANONYMIZE_RECORD": "REMEDIATION",
            "VERIFY_RECORD_ABSENT": "VERIFICATION",
            "VERIFY_RECORD_PRESENT": "VERIFICATION",
            "VERIFY_RECORD_REDACTED": "VERIFICATION",
            "VERIFY_RECORD_ANONYMIZED": "VERIFICATION",
            "VERIFY_DATA_FLOW_DISABLED": "VERIFICATION",
            "VERIFY_RESTORE_BLOCKED": "VERIFICATION",
        }
        operation_names = [
            "REPORT_RESTORE_RISK",
            "REPORT_REMAINING_RECORD",
            "REPORT_ACTIVE_DATA_FLOW",
            "REPORT_EXPOSED_PII",
            "DISABLE_DATA_FLOW",
            "BLOCK_RESTORE",
            "DELETE_RECORD",
            "REDACT_RECORD",
            "ANONYMIZE_RECORD",
            "VERIFY_RESTORE_BLOCKED",
            "VERIFY_RECORD_ANONYMIZED",
            "VERIFY_RECORD_PRESENT",
            "VERIFY_RECORD_ABSENT",
            "VERIFY_RECORD_REDACTED",
            "VERIFY_DATA_FLOW_DISABLED",
        ]
        self.assertEqual(
            [
                item[0]
                for item in sorted(
                    [(name, "a", "z") for name in operation_names],
                    key=lambda item: (
                        main.PHASE_ORDER[operation_phases[item[0]]],
                        main.OPERATION_ORDER[item[0]],
                        item[1],
                        item[2],
                    ),
                )
            ],
            [
                "REPORT_REMAINING_RECORD",
                "REPORT_EXPOSED_PII",
                "REPORT_ACTIVE_DATA_FLOW",
                "REPORT_RESTORE_RISK",
                "DISABLE_DATA_FLOW",
                "BLOCK_RESTORE",
                "DELETE_RECORD",
                "REDACT_RECORD",
                "ANONYMIZE_RECORD",
                "VERIFY_RECORD_ABSENT",
                "VERIFY_RECORD_PRESENT",
                "VERIFY_RECORD_REDACTED",
                "VERIFY_RECORD_ANONYMIZED",
                "VERIFY_DATA_FLOW_DISABLED",
                "VERIFY_RESTORE_BLOCKED",
            ],
        )
        operations = [
            ("VERIFY_RESTORE_BLOCKED", "backup_service", "b"),
            ("VERIFY_RECORD_ANONYMIZED", "analytics_platform", "a"),
            ("VERIFY_RECORD_PRESENT", "security_service", "s"),
            ("VERIFY_RECORD_ABSENT", "account_service", "a"),
            ("VERIFY_RECORD_REDACTED", "support_platform", "r"),
            ("VERIFY_DATA_FLOW_DISABLED", "integration_service", "d"),
        ]
        steps = [
            main.step("VERIFICATION", system, resource, operation, "PRESENT", "")
            for operation, system, resource in operations
        ]
        ordered = main.ordered_steps(steps)
        self.assertEqual(
            [step["operation"] for step in ordered],
            [
                "VERIFY_RECORD_ABSENT",
                "VERIFY_RECORD_PRESENT",
                "VERIFY_RECORD_REDACTED",
                "VERIFY_RECORD_ANONYMIZED",
                "VERIFY_DATA_FLOW_DISABLED",
                "VERIFY_RESTORE_BLOCKED",
            ],
        )

    def test_same_operation_sorts_by_system_then_resource(self) -> None:
        steps = [
            main.step("FINDING", "z", "b", "REPORT_REMAINING_RECORD", "PRESENT", ""),
            main.step("FINDING", "a", "z", "REPORT_REMAINING_RECORD", "PRESENT", ""),
            main.step("FINDING", "a", "a", "REPORT_REMAINING_RECORD", "PRESENT", ""),
        ]
        ordered = main.ordered_steps(steps)
        self.assertEqual(
            [(step["system_id"], step["resource_id"]) for step in ordered],
            [("a", "a"), ("a", "z"), ("z", "b")],
        )

    def test_audit_cutoff_excludes_later_evidence(self) -> None:
        record = main.Evidence(
            "account_service",
            "account_9",
            "USER_PROFILE",
            "ABSENT",
            "evidence_1",
            "2026-01-02T00:00:00Z",
            {},
            "",
        )
        cutoff = main.parse_time("2026-01-01T00:00:00Z")
        self.assertIsNotNone(cutoff)
        self.assertFalse(
            main.evidence_at_cutoff(record, cutoff, {"evidence_1": "2026-01-01T00:00:00Z"})
        )

    def test_step_order_is_phase_operation_then_resource(self) -> None:
        steps = [
            main.step("VERIFICATION", "a", "z", "VERIFY_RECORD_ABSENT", "ABSENT", ""),
            main.step("FINDING", "b", "z", "REPORT_REMAINING_RECORD", "PRESENT", "evidence_1"),
            main.step("FINDING", "a", "a", "REPORT_EXPOSED_PII", "PRESENT", "evidence_2"),
        ]
        ordered = main.ordered_steps(steps)
        self.assertEqual(
            [(item["phase"], item["operation"], item["system_id"]) for item in ordered],
            [
                ("FINDING", "REPORT_REMAINING_RECORD", "b"),
                ("FINDING", "REPORT_EXPOSED_PII", "a"),
                ("VERIFICATION", "VERIFY_RECORD_ABSENT", "a"),
            ],
        )

    def test_incomplete_case_verifies_each_absent_account_copy(self) -> None:
        observed_at = "2026-01-01T12:00:00Z"
        evidence = [
            main.Evidence(
                "account_service",
                "account_present",
                "USER_PROFILE",
                "PRESENT",
                "profile_present",
                observed_at,
                {"user_id": "user_1"},
                "",
            ),
            main.Evidence(
                "account_service",
                "account_absent",
                "USER_PROFILE",
                "ABSENT",
                "profile_absent",
                observed_at,
                {"user_id": "user_1"},
                "",
            ),
            main.Evidence(
                "search_service",
                "search_1",
                "SEARCH_INDEX_ENTRY",
                "PRESENT",
                "search_present",
                observed_at,
                {"user_id": "user_1"},
                "",
            ),
        ]
        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "reported_at": "",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": observed_at}},
            {"user@example.test": {"user_1"}},
            [],
            evidence,
            {item.evidence_id: observed_at for item in evidence},
            [],
            {"USER_PROFILE": "DELETE", "SEARCH_INDEX_ENTRY": "DELETE"},
        )

        self.assertEqual(status, "INCOMPLETE")
        self.assertIn(
            ("account_absent", "VERIFY_RECORD_ABSENT", "ABSENT", ""),
            [
                (item["resource_id"], item["operation"], item["state"], item["evidence_id"])
                for item in steps
            ],
        )

    def test_unique_report_time_match_and_absent_snapshot_do_not_establish_ownership(self) -> None:
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T12:00:00Z",
            {"resource_ids": []},
            "",
        )
        activity = {
            "event_type": "DELETE_RECORD",
            "source_system": "deletion_worker",
            "target_system": "account_service",
            "resource_id": "account_123",
            "event_time": "2026-01-01T12:00:00Z",
            "details": "Deletion worker submitted primary profile account_123.",
        }

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "reported_at": "2026-01-01T12:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [snapshot],
            {"snapshot_evidence": "2026-01-01T12:00:00Z"},
            [activity],
            {},
        )

        self.assertEqual((status, steps), ("INCOMPLETE", []))

    def test_identity_linked_source_resource_id_and_absent_snapshot_link_account(self) -> None:
        linked_record = main.Evidence(
            "search_service",
            "search_1",
            "SEARCH_INDEX_ENTRY",
            "PRESENT",
            "linked_search_evidence",
            "2026-01-01T12:00:00Z",
            {
                "resource_id": "search_1",
                "display_name": "User One",
                "email": "user@example.test",
                "source_resource_id": "account_123",
            },
            "",
        )
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T18:00:00Z",
            {"resource_ids": []},
            "",
        )

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [linked_record, snapshot],
            {
                "linked_search_evidence": "2026-01-01T12:00:00Z",
                "snapshot_evidence": "2026-01-01T18:00:00Z",
            },
            [],
            {"USER_PROFILE": "DELETE", "SEARCH_INDEX_ENTRY": "DELETE"},
        )

        self.assertEqual(status, "INCOMPLETE")
        self.assertIn(
            ("account_123", "VERIFY_RECORD_ABSENT", ""),
            [(step["resource_id"], step["operation"], step["evidence_id"]) for step in steps],
        )

    def test_post_cutoff_source_resource_reference_cannot_link_account(self) -> None:
        linked_record = main.Evidence(
            "search_service",
            "search_1",
            "SEARCH_INDEX_ENTRY",
            "PRESENT",
            "late_search_evidence",
            "2026-01-01T12:00:00Z",
            {
                "resource_id": "search_1",
                "email": "user@example.test",
                "source_resource_id": "account_123",
            },
            "",
        )
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T18:00:00Z",
            {"resource_ids": []},
            "",
        )

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [linked_record, snapshot],
            {
                "late_search_evidence": "2026-01-03T00:00:00Z",
                "snapshot_evidence": "2026-01-01T18:00:00Z",
            },
            [],
            {"USER_PROFILE": "DELETE", "SEARCH_INDEX_ENTRY": "DELETE"},
        )

        self.assertEqual(status, "INCOMPLETE")
        self.assertNotIn(
            ("account_123", "VERIFY_RECORD_ABSENT"),
            [(step["resource_id"], step["operation"]) for step in steps],
        )

    def test_conflicting_identity_for_referenced_account_blocks_ownership(self) -> None:
        subject_record = main.Evidence(
            "search_service",
            "search_1",
            "SEARCH_INDEX_ENTRY",
            "PRESENT",
            "subject_search_evidence",
            "2026-01-01T12:00:00Z",
            {
                "resource_id": "search_1",
                "email": "user@example.test",
                "source_resource_id": "account_123",
            },
            "",
        )
        conflicting_record = main.Evidence(
            "search_service",
            "search_2",
            "SEARCH_INDEX_ENTRY",
            "PRESENT",
            "conflicting_search_evidence",
            "2026-01-01T13:00:00Z",
            {
                "resource_id": "search_2",
                "user_id": "user_2",
                "email": "other@example.test",
                "source_resource_id": "account_123",
            },
            "",
        )
        direct_conflicting_record = main.Evidence(
            "account_service",
            "account_123",
            "USER_PROFILE",
            "PRESENT",
            "conflicting_profile_evidence",
            "2026-01-01T14:00:00Z",
            {"resource_id": "account_123", "user_id": "user_2"},
            "",
        )
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T18:00:00Z",
            {"resource_ids": []},
            "",
        )

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "request_text": "Please delete my account.",
            },
            {
                "user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"},
                "user_2": {"email": "other@example.test", "updated_at": "2026-01-01T00:00:00Z"},
            },
            {
                "user@example.test": {"user_1"},
                "other@example.test": {"user_2"},
            },
            [],
            [subject_record, conflicting_record, direct_conflicting_record, snapshot],
            {
                "subject_search_evidence": "2026-01-01T12:00:00Z",
                "conflicting_search_evidence": "2026-01-01T13:00:00Z",
                "conflicting_profile_evidence": "2026-01-01T14:00:00Z",
                "snapshot_evidence": "2026-01-01T18:00:00Z",
            },
            [],
            {"USER_PROFILE": "DELETE", "SEARCH_INDEX_ENTRY": "DELETE"},
        )

        self.assertEqual(status, "INCOMPLETE")
        self.assertNotIn(
            ("account_123", "VERIFY_RECORD_ABSENT"),
            [(step["resource_id"], step["operation"]) for step in steps],
        )

    def test_multiple_time_correlated_account_targets_are_not_linked(self) -> None:
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T12:00:00Z",
            {"resource_ids": []},
            "",
        )
        activities = [
            {
                "event_type": "DELETE_RECORD",
                "source_system": "deletion_worker",
                "target_system": "account_service",
                "resource_id": resource_id,
                "event_time": "2026-01-01T12:00:00Z",
                "details": f"Deletion worker submitted primary profile {resource_id}.",
            }
            for resource_id in ("account_123", "account_456")
        ]

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "reported_at": "2026-01-01T12:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [snapshot],
            {"snapshot_evidence": "2026-01-01T12:00:00Z"},
            activities,
            {},
        )

        self.assertEqual((status, steps), ("INCOMPLETE", []))

    def test_explicitly_unrelated_account_activity_is_not_time_linked(self) -> None:
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T12:00:00Z",
            {"resource_ids": []},
            "",
        )
        activity = {
            "event_type": "DELETE_RECORD",
            "source_system": "deletion_worker",
            "target_system": "account_service",
            "resource_id": "account_123",
            "event_time": "2026-01-01T12:00:00Z",
            "details": "Deletion worker submitted account_123 for user_18.",
        }

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "reported_at": "2026-01-01T12:00:00Z",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [snapshot],
            {"snapshot_evidence": "2026-01-01T12:00:00Z"},
            [activity],
            {},
        )

        self.assertEqual((status, steps), ("INCOMPLETE", []))

    def test_account_activity_with_exact_subject_reference_can_be_linked(self) -> None:
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T12:00:00Z",
            {"resource_ids": []},
            "",
        )
        activity = {
            "event_type": "DELETE_RECORD",
            "source_system": "deletion_worker",
            "target_system": "account_service",
            "resource_id": "account_123",
            "event_time": "2026-01-01T12:00:00Z",
            "details": "Deletion worker submitted account_123 for user_1.",
            "reported_result": "SUCCESS",
        }

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "reported_at": "",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [snapshot],
            {"snapshot_evidence": "2026-01-01T12:00:00Z"},
            [activity],
            {},
        )

        self.assertEqual(status, "COMPLETE")
        self.assertEqual(
            [(item["resource_id"], item["operation"], item["evidence_id"]) for item in steps],
            [("account_123", "VERIFY_RECORD_ABSENT", "snapshot_evidence")],
        )

    def test_user_id_substring_does_not_link_another_user_activity(self) -> None:
        snapshot = main.Evidence(
            "account_service",
            "__account_snapshot__",
            "ACCOUNT_SNAPSHOT",
            "UNKNOWN",
            "snapshot_evidence",
            "2026-01-01T12:00:00Z",
            {"resource_ids": []},
            "",
        )
        activity = {
            "event_type": "DELETE_RECORD",
            "source_system": "deletion_worker",
            "target_system": "account_service",
            "resource_id": "account_123",
            "event_time": "2026-01-01T12:00:00Z",
            "details": "Deletion worker submitted account_123 for user_10.",
        }

        status, steps = main.build_case(
            {
                "case_id": "case_test",
                "email": "user@example.test",
                "audit_at": "2026-01-02T00:00:00Z",
                "reported_at": "",
                "request_text": "Please delete my account.",
            },
            {"user_1": {"email": "user@example.test", "updated_at": "2026-01-01T00:00:00Z"}},
            {"user@example.test": {"user_1"}},
            [],
            [snapshot],
            {"snapshot_evidence": "2026-01-01T12:00:00Z"},
            [activity],
            {},
        )

        self.assertEqual((status, steps), ("INCOMPLETE", []))


class OutputContractTests(unittest.TestCase):
    def test_operation_must_use_its_allowed_phase_and_state(self) -> None:
        valid_row = {
            "case_id": "case_001",
            "steps_json": (
                '[{"step_no":1,"phase":"REMEDIATION","system_id":"account_service",'
                '"resource_id":"account_1","operation":"DELETE_RECORD",'
                '"state":"ABSENT","evidence_id":""}]'
            ),
        }
        evaluation.parse_steps(valid_row)

        invalid_row = {
            **valid_row,
            "steps_json": valid_row["steps_json"].replace('"state":"ABSENT"', '"state":"PRESENT"'),
        }
        with self.assertRaisesRegex(ValueError, "operation/state contract"):
            evaluation.parse_steps(invalid_row)


if __name__ == "__main__":
    unittest.main()
